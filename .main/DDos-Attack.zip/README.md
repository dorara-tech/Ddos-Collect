# DDos-Attack 
### What Is A DDos-Attack

### A Distributed Denial of Service (DDoS) attack is an attempt to make an online service unavailable 
by overwhelming it with traffic from multiple sources. They target a wide variety of important resources
from banks to news websites, and present a major challenge to making sure people can publish and access important information

### Dwonload&Install

### git clone https://github.com/Ha3MrX/DDos-Attack

### cd DDos-Attack

### chmod +x ddos-attack.py

### python ddos-attack.py

### ScreenShot 

### YouTube channel

https://www.youtube.com/channel/UCCgy7i_A5yhAEdY86rPOinA

### Video Tutorial

https://www.youtube.com/watch?v=-e3Iia_P7rA

